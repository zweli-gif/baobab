export const ceoReflections = mysqlTable("ceoReflections", {
  id: int("id").autoincrement().primaryKey(),
  content: text("content").notNull(), // Max ~10 lines of text
  weekNumber: int("weekNumber").notNull(), // ISO week number
  year: int("year").notNull(),
  createdBy: int("createdBy").notNull(), // CEO user ID
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CeoReflection = typeof ceoReflections.$inferSelect;
export type InsertCeoReflection = typeof ceoReflections.$inferInsert;


/**