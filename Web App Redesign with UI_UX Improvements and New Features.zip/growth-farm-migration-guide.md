# Growth Farm Platform - Migration Guide
## From Manus Infrastructure to Free Services

**Document Version:** 1.0  
**Last Updated:** February 26, 2026  
**Author:** Manus AI

---

## Executive Summary

This guide provides a comprehensive roadmap for migrating the Growth Farm Operating System from Manus-hosted infrastructure to free-tier services. The platform currently relies on Manus for database hosting, authentication, file storage, and deployment. This migration will enable you to run the platform independently while minimizing costs.

**Estimated Migration Time:** 8-12 hours for a developer familiar with the stack  
**Estimated Monthly Cost After Migration:** $0 (within free tier limits)  
**Technical Complexity:** Moderate (requires familiarity with React, Node.js, and cloud services)

---

## Current Architecture (Manus-Based)

The Growth Farm platform currently uses the following Manus-provided services:

| Service | Current Provider | Purpose | Environment Variables |
|---------|-----------------|---------|----------------------|
| Database | Manus TiDB/MySQL | Data persistence | `DATABASE_URL` |
| Authentication | Manus OAuth | User login/sessions | `OAUTH_SERVER_URL`, `JWT_SECRET`, `VITE_OAUTH_PORTAL_URL` |
| File Storage | Manus S3 | Image/document uploads | `BUILT_IN_FORGE_API_URL`, `BUILT_IN_FORGE_API_KEY` |
| Hosting | Manus Platform | Web application deployment | N/A |
| Analytics | Manus Analytics | Usage tracking | `VITE_ANALYTICS_ENDPOINT`, `VITE_ANALYTICS_WEBSITE_ID` |

---

## Recommended Free Services Stack

The following free-tier services provide equivalent functionality:

| Service | Recommended Provider | Free Tier Limits | Why This Choice |
|---------|---------------------|------------------|-----------------|
| Database | **Supabase** | 500MB storage, unlimited API requests | PostgreSQL-compatible, generous free tier, built-in auth option |
| Authentication | **Clerk** | 10,000 monthly active users | Easy integration, social logins, user management UI |
| File Storage | **Cloudflare R2** | 10GB storage, 1M Class A operations/month | S3-compatible API, no egress fees |
| Hosting | **Vercel** | Unlimited bandwidth, 100GB/month | Zero-config deployment, edge functions, great DX |
| Analytics | **Plausible (self-hosted)** or **Umami** | Unlimited (self-hosted) | Privacy-focused, lightweight, GDPR-compliant |

**Alternative Stack Options:**

- **Budget Option:** Supabase (database + auth + storage) + Vercel (hosting) = 2 services only
- **All-in-One Option:** Supabase for everything except hosting, Vercel for deployment
- **Enterprise-Ready Option:** PlanetScale (database) + Auth0 (auth) + Vercel Blob (storage) + Vercel (hosting)

---

## Migration Roadmap

### Phase 1: Database Migration (2-3 hours)

**Goal:** Move from Manus TiDB to Supabase PostgreSQL

#### Step 1.1: Create Supabase Project

1. Sign up at [supabase.com](https://supabase.com)
2. Create a new project (choose region closest to your users)
3. Note down the connection string from Project Settings → Database

#### Step 1.2: Update Database Schema

The current schema uses Drizzle ORM with MySQL syntax. You'll need to make minor adjustments for PostgreSQL:

**Files to modify:**
- `drizzle/schema.ts`
- `drizzle.config.ts`

**Key changes:**

```typescript
// BEFORE (MySQL)
import { mysqlTable, int, varchar, text, timestamp } from 'drizzle-orm/mysql-core';

export const users = mysqlTable('users', {
  id: int('id').primaryKey().autoincrement(),
  createdAt: timestamp('created_at').defaultNow(),
});

// AFTER (PostgreSQL)
import { pgTable, serial, varchar, text, timestamp } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  createdAt: timestamp('created_at').defaultNow(),
});
```

**Common MySQL → PostgreSQL conversions:**

| MySQL Type | PostgreSQL Type | Drizzle Change |
|-----------|----------------|----------------|
| `int().autoincrement()` | `serial()` | Change import and function |
| `varchar(255)` | `varchar(255)` | No change |
| `text()` | `text()` | No change |
| `timestamp().defaultNow()` | `timestamp().defaultNow()` | No change |
| `boolean()` | `boolean()` | No change |

#### Step 1.3: Export Data from Manus

```bash
# From Manus Management UI → Database panel
# Export each table as CSV

# Or use the database connection string to dump data
mysqldump -h <manus-host> -u <user> -p <database> > growth-farm-backup.sql
```

#### Step 1.4: Import Data to Supabase

```bash
# Install PostgreSQL client
brew install postgresql  # macOS
sudo apt install postgresql-client  # Linux

# Convert MySQL dump to PostgreSQL format (if needed)
# Use online tools or pgloader

# Import to Supabase
psql "postgresql://postgres:[YOUR-PASSWORD]@[YOUR-PROJECT-REF].supabase.co:5432/postgres" < growth-farm-postgres.sql
```

#### Step 1.5: Update Environment Variables

```bash
# .env.local
DATABASE_URL="postgresql://postgres:[PASSWORD]@[PROJECT-REF].supabase.co:5432/postgres"
```

#### Step 1.6: Run Migrations

```bash
cd growth-farm
pnpm db:push
```

---

### Phase 2: Authentication Migration (3-4 hours)

**Goal:** Replace Manus OAuth with Clerk authentication

#### Step 2.1: Create Clerk Application

1. Sign up at [clerk.com](https://clerk.com)
2. Create a new application
3. Enable email/password and social providers (Google, GitHub, etc.)
4. Copy the publishable key and secret key

#### Step 2.2: Install Clerk SDK

```bash
cd growth-farm
pnpm add @clerk/clerk-react @clerk/backend
```

#### Step 2.3: Replace Authentication Code

**Files to modify:**
- `server/_core/oauth.ts` → Delete (replace with Clerk)
- `server/_core/context.ts` → Update to use Clerk
- `client/src/main.tsx` → Wrap app with ClerkProvider
- `client/src/contexts/AuthContext.tsx` → Update to use Clerk hooks

**New `server/_core/clerk.ts`:**

```typescript
import { ClerkExpressRequireAuth } from '@clerk/clerk-sdk-node';

export const clerkAuth = ClerkExpressRequireAuth({
  secretKey: process.env.CLERK_SECRET_KEY,
});

export async function getUserFromClerk(userId: string) {
  const { clerkClient } = await import('@clerk/clerk-sdk-node');
  return clerkClient.users.getUser(userId);
}
```

**Update `server/_core/context.ts`:**

```typescript
import { inferAsyncReturnType } from '@trpc/server';
import { CreateExpressContextOptions } from '@trpc/server/adapters/express';

export async function createContext({ req, res }: CreateExpressContextOptions) {
  const userId = req.auth?.userId; // From Clerk middleware
  
  if (!userId) {
    return { user: null };
  }

  // Fetch user from your database using Clerk userId
  const user = await getUserById(userId);
  
  return { user };
}

export type Context = inferAsyncReturnType<typeof createContext>;
```

**Update `client/src/main.tsx`:**

```typescript
import { ClerkProvider } from '@clerk/clerk-react';

const CLERK_PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ClerkProvider publishableKey={CLERK_PUBLISHABLE_KEY}>
      <App />
    </ClerkProvider>
  </React.StrictMode>
);
```

**Update `client/src/contexts/AuthContext.tsx`:**

```typescript
import { useUser, useClerk } from '@clerk/clerk-react';

export function useAuth() {
  const { user, isLoaded } = useUser();
  const { signOut } = useClerk();
  
  return {
    user: user ? {
      id: user.id,
      name: user.fullName,
      email: user.primaryEmailAddress?.emailAddress,
      avatarUrl: user.imageUrl,
    } : null,
    isLoading: !isLoaded,
    logout: signOut,
  };
}

export function getLoginUrl() {
  return '/sign-in'; // Clerk handles routing
}
```

#### Step 2.4: Update Environment Variables

```bash
# .env
CLERK_SECRET_KEY="sk_test_..."

# .env.local (client)
VITE_CLERK_PUBLISHABLE_KEY="pk_test_..."
```

#### Step 2.5: Update User Schema

Add Clerk user ID mapping to your users table:

```typescript
// drizzle/schema.ts
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  clerkId: varchar('clerk_id', { length: 255 }).unique(), // NEW
  email: varchar('email', { length: 255 }).notNull().unique(),
  name: varchar('name', { length: 255 }),
  // ... other fields
});
```

Run migration:

```bash
pnpm db:push
```

#### Step 2.6: Sync Users on First Login

Create a webhook or sync logic to create database records when users sign up via Clerk:

```typescript
// server/routers.ts - Add this procedure
syncUser: publicProcedure
  .input(z.object({ clerkId: z.string() }))
  .mutation(async ({ input, ctx }) => {
    const clerkUser = await getUserFromClerk(input.clerkId);
    
    // Upsert user in database
    await db.insert(users).values({
      clerkId: input.clerkId,
      email: clerkUser.emailAddresses[0].emailAddress,
      name: clerkUser.fullName,
    }).onConflictDoUpdate({
      target: users.clerkId,
      set: { name: clerkUser.fullName },
    });
  }),
```

---

### Phase 3: File Storage Migration (1-2 hours)

**Goal:** Replace Manus S3 with Cloudflare R2

#### Step 3.1: Create Cloudflare R2 Bucket

1. Sign up at [cloudflare.com](https://cloudflare.com)
2. Navigate to R2 Object Storage
3. Create a new bucket (e.g., `growth-farm-files`)
4. Generate API token with read/write permissions

#### Step 3.2: Install AWS SDK (R2 is S3-compatible)

```bash
pnpm add @aws-sdk/client-s3 @aws-sdk/s3-request-presigner
```

#### Step 3.3: Replace Storage Helper

**Update `server/storage.ts`:**

```typescript
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const s3Client = new S3Client({
  region: 'auto',
  endpoint: `https://${process.env.CLOUDFLARE_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
});

const BUCKET_NAME = 'growth-farm-files';

export async function storagePut(
  key: string,
  data: Buffer | Uint8Array | string,
  contentType?: string
): Promise<{ key: string; url: string }> {
  const command = new PutObjectCommand({
    Bucket: BUCKET_NAME,
    Key: key,
    Body: data,
    ContentType: contentType,
  });

  await s3Client.send(command);

  return {
    key,
    url: `https://pub-${process.env.CLOUDFLARE_ACCOUNT_ID}.r2.dev/${key}`,
  };
}

export async function storageGet(
  key: string,
  expiresIn: number = 3600
): Promise<{ key: string; url: string }> {
  const command = new GetObjectCommand({
    Bucket: BUCKET_NAME,
    Key: key,
  });

  const url = await getSignedUrl(s3Client, command, { expiresIn });

  return { key, url };
}
```

#### Step 3.4: Update Environment Variables

```bash
# .env
CLOUDFLARE_ACCOUNT_ID="your-account-id"
R2_ACCESS_KEY_ID="your-access-key"
R2_SECRET_ACCESS_KEY="your-secret-key"
```

#### Step 3.5: Configure Public Access (Optional)

If you want files to be publicly accessible without signed URLs:

1. In Cloudflare R2 dashboard, enable public access for your bucket
2. Update `storagePut` to return public URL directly

---

### Phase 4: Hosting Migration (1-2 hours)

**Goal:** Deploy to Vercel instead of Manus

#### Step 4.1: Prepare for Vercel Deployment

**Create `vercel.json`:**

```json
{
  "version": 2,
  "builds": [
    {
      "src": "server/_core/index.ts",
      "use": "@vercel/node"
    },
    {
      "src": "client/package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "server/_core/index.ts"
    },
    {
      "src": "/(.*)",
      "dest": "client/dist/$1"
    }
  ]
}
```

**Update `package.json`:**

```json
{
  "scripts": {
    "build": "pnpm run build:client && pnpm run build:server",
    "build:client": "cd client && vite build",
    "build:server": "tsc --project server/tsconfig.json",
    "vercel-build": "pnpm build"
  }
}
```

#### Step 4.2: Deploy to Vercel

```bash
# Install Vercel CLI
pnpm add -g vercel

# Login
vercel login

# Deploy
cd growth-farm
vercel

# Follow prompts to link project
```

#### Step 4.3: Configure Environment Variables in Vercel

1. Go to Vercel dashboard → Your Project → Settings → Environment Variables
2. Add all environment variables:
   - `DATABASE_URL`
   - `CLERK_SECRET_KEY`
   - `VITE_CLERK_PUBLISHABLE_KEY`
   - `R2_ACCESS_KEY_ID`
   - `R2_SECRET_ACCESS_KEY`
   - `CLOUDFLARE_ACCOUNT_ID`

#### Step 4.4: Set Up Custom Domain (Optional)

1. In Vercel dashboard → Domains
2. Add your custom domain (e.g., `app.growthfarm.com`)
3. Update DNS records as instructed

---

### Phase 5: Analytics Migration (Optional, 30 minutes)

**Goal:** Replace Manus Analytics with self-hosted Umami

#### Step 5.1: Deploy Umami to Vercel

```bash
# Clone Umami
git clone https://github.com/umami-software/umami.git
cd umami

# Deploy to Vercel
vercel

# Add DATABASE_URL pointing to your Supabase database
```

#### Step 5.2: Update Client Code

**Remove Manus analytics:**

```typescript
// client/src/main.tsx
// DELETE these lines:
// import { initAnalytics } from './lib/analytics';
// initAnalytics();
```

**Add Umami tracking script:**

```html
<!-- client/index.html -->
<script
  async
  defer
  data-website-id="your-website-id"
  src="https://your-umami-domain.vercel.app/umami.js"
></script>
```

---

## Code Changes Summary

### Files to Modify

| File Path | Changes Required | Complexity |
|-----------|-----------------|------------|
| `drizzle/schema.ts` | MySQL → PostgreSQL syntax | Medium |
| `drizzle.config.ts` | Update dialect to `pg` | Low |
| `server/_core/oauth.ts` | Delete and replace with Clerk | High |
| `server/_core/context.ts` | Update to use Clerk auth | Medium |
| `server/storage.ts` | Replace with Cloudflare R2 | Medium |
| `client/src/main.tsx` | Add ClerkProvider wrapper | Low |
| `client/src/contexts/AuthContext.tsx` | Use Clerk hooks | Medium |
| `.env` | Update all environment variables | Low |
| `package.json` | Add new dependencies | Low |
| `vercel.json` | Create for deployment | Low |

### Files to Delete

- `server/_core/oauth.ts` (replaced by Clerk)
- Any Manus-specific configuration files

### New Files to Create

- `server/_core/clerk.ts` (Clerk authentication helper)
- `vercel.json` (Vercel deployment configuration)
- `.env.example` (template for environment variables)

---

## Environment Variables Reference

### Manus (Current)

```bash
# Database
DATABASE_URL="mysql://..."

# Authentication
JWT_SECRET="..."
OAUTH_SERVER_URL="https://api.manus.im"
VITE_OAUTH_PORTAL_URL="https://login.manus.im"
OWNER_OPEN_ID="..."
OWNER_NAME="..."

# Storage & APIs
BUILT_IN_FORGE_API_URL="..."
BUILT_IN_FORGE_API_KEY="..."
VITE_FRONTEND_FORGE_API_KEY="..."
VITE_FRONTEND_FORGE_API_URL="..."

# Analytics
VITE_ANALYTICS_ENDPOINT="..."
VITE_ANALYTICS_WEBSITE_ID="..."

# App
VITE_APP_ID="..."
VITE_APP_TITLE="Growth Farm"
VITE_APP_LOGO="..."
```

### Free Services (After Migration)

```bash
# Database (Supabase)
DATABASE_URL="postgresql://postgres:[PASSWORD]@[PROJECT-REF].supabase.co:5432/postgres"

# Authentication (Clerk)
CLERK_SECRET_KEY="sk_test_..."
VITE_CLERK_PUBLISHABLE_KEY="pk_test_..."

# Storage (Cloudflare R2)
CLOUDFLARE_ACCOUNT_ID="..."
R2_ACCESS_KEY_ID="..."
R2_SECRET_ACCESS_KEY="..."

# App
VITE_APP_TITLE="Growth Farm"
VITE_APP_LOGO="/logo.png"

# Analytics (Umami - optional)
VITE_UMAMI_WEBSITE_ID="..."
VITE_UMAMI_URL="https://your-umami.vercel.app"
```

---

## Testing Checklist

After completing the migration, test the following functionality:

### Authentication
- [ ] User can sign up with email/password
- [ ] User can log in with email/password
- [ ] User can log in with Google (if enabled)
- [ ] User session persists across page refreshes
- [ ] User can log out successfully
- [ ] Protected routes redirect to login when not authenticated

### Database Operations
- [ ] All existing data is visible in the app
- [ ] Create operations work (add celebration, add activity, etc.)
- [ ] Update operations work (edit KPI, update health score, etc.)
- [ ] Delete operations work (remove activity, delete celebration, etc.)
- [ ] Relationships are preserved (users → activities, goals → KPIs, etc.)

### File Storage
- [ ] User can upload profile picture
- [ ] Uploaded images display correctly
- [ ] Files are accessible via public URLs
- [ ] Large files (>1MB) upload successfully

### Core Features
- [ ] Home page displays team health correctly
- [ ] Weekly page shows activities and allows editing
- [ ] Monthly page displays KPI progress wheels
- [ ] Settings page allows editing goals and team members
- [ ] Dashboard shows all metrics correctly
- [ ] Engine modal opens all 6 pipeline views

### Performance
- [ ] Page load time < 3 seconds
- [ ] Database queries complete in < 500ms
- [ ] File uploads complete in < 10 seconds
- [ ] No console errors in browser

---

## Troubleshooting Common Issues

### Issue 1: Database Connection Fails

**Symptoms:** `Error: connect ETIMEDOUT` or `Connection refused`

**Solutions:**
1. Check that `DATABASE_URL` is correct in `.env`
2. Verify Supabase project is not paused (free tier pauses after 7 days of inactivity)
3. Check IP allowlist in Supabase dashboard (should allow all IPs for development)
4. Ensure SSL is enabled: append `?sslmode=require` to connection string

### Issue 2: Authentication Redirects Fail

**Symptoms:** User gets stuck on login page or sees "Invalid redirect URL"

**Solutions:**
1. Add your Vercel domain to Clerk's allowed redirect URLs
2. Update `CLERK_PUBLISHABLE_KEY` to match your environment (test vs production)
3. Check that ClerkProvider is wrapping your entire app in `main.tsx`

### Issue 3: File Uploads Return 403 Forbidden

**Symptoms:** `AccessDenied` error when uploading files

**Solutions:**
1. Verify R2 API token has write permissions
2. Check bucket name matches `BUCKET_NAME` in `storage.ts`
3. Ensure CORS is configured on R2 bucket (allow your domain)
4. Confirm `CLOUDFLARE_ACCOUNT_ID` is correct

### Issue 4: Vercel Build Fails

**Symptoms:** `Error: Cannot find module` or `Build failed`

**Solutions:**
1. Run `pnpm install` locally to ensure all dependencies are in `package.json`
2. Check that `vercel-build` script exists in `package.json`
3. Verify all environment variables are set in Vercel dashboard
4. Check build logs for specific missing dependencies and install them

### Issue 5: Data Migration Incomplete

**Symptoms:** Some tables or records are missing after migration

**Solutions:**
1. Export data from Manus as CSV for each table individually
2. Use Supabase Table Editor to manually import CSVs
3. Verify foreign key relationships are preserved
4. Run data validation queries to check record counts match

---

## Cost Comparison

### Manus Platform (Current)

| Service | Estimated Monthly Cost |
|---------|----------------------|
| All-inclusive hosting | Variable (contact Manus support) |

### Free Services Stack (After Migration)

| Service | Free Tier Limits | Estimated Monthly Cost |
|---------|-----------------|----------------------|
| Supabase (Database) | 500MB, unlimited requests | $0 |
| Clerk (Auth) | 10,000 monthly active users | $0 |
| Cloudflare R2 (Storage) | 10GB, 1M operations | $0 |
| Vercel (Hosting) | 100GB bandwidth | $0 |
| **Total** | | **$0** |

**When you'll need to upgrade:**

- **Database:** When you exceed 500MB (approximately 50,000+ activities + 1,000+ users)
- **Auth:** When you exceed 10,000 monthly active users
- **Storage:** When you exceed 10GB of files (approximately 10,000+ images)
- **Hosting:** When you exceed 100GB/month bandwidth (approximately 100,000+ page views)

**Estimated paid tier costs (if needed):**

- Supabase Pro: $25/month (8GB database, 50GB bandwidth)
- Clerk Pro: $25/month (unlimited users, advanced features)
- Cloudflare R2: ~$0.015/GB storage, $0.36/million operations
- Vercel Pro: $20/month (unlimited bandwidth, advanced features)

**Total estimated cost at scale:** $70-100/month for 50,000+ users

---

## Rollback Plan

If migration fails or you encounter critical issues, you can rollback to Manus:

### Step 1: Restore Environment Variables

```bash
# Copy .env.backup to .env
cp .env.manus.backup .env
```

### Step 2: Restore Code Changes

```bash
# If using Git
git reset --hard <commit-before-migration>

# If not using Git, restore from backup
cp -r growth-farm-backup/* growth-farm/
```

### Step 3: Redeploy to Manus

Use the Manus Management UI to publish the previous checkpoint.

### Step 4: Restore Database (if needed)

Import the MySQL backup you created in Phase 1:

```bash
mysql -h <manus-host> -u <user> -p <database> < growth-farm-backup.sql
```

---

## Post-Migration Optimization

Once migration is complete and tested, consider these optimizations:

### 1. Enable Edge Functions

Move tRPC procedures to Vercel Edge Functions for faster response times:

```typescript
// server/edge/trpc.ts
export const config = {
  runtime: 'edge',
};

export default async function handler(req: Request) {
  // Your tRPC handler
}
```

### 2. Add Database Indexes

Optimize query performance by adding indexes to frequently queried columns:

```sql
-- Add indexes for common queries
CREATE INDEX idx_users_clerk_id ON users(clerk_id);
CREATE INDEX idx_activities_user_id ON weekly_activities(user_id);
CREATE INDEX idx_activities_due_day ON weekly_activities(due_day);
CREATE INDEX idx_celebrations_date ON celebrations(celebration_date);
```

### 3. Implement Caching

Use Vercel's edge caching for static data:

```typescript
// server/routers.ts
export const config = {
  revalidate: 60, // Cache for 60 seconds
};
```

### 4. Set Up Monitoring

Add error tracking and performance monitoring:

```bash
pnpm add @sentry/react @sentry/node
```

### 5. Enable Backups

Set up automated database backups in Supabase:

1. Go to Supabase dashboard → Database → Backups
2. Enable daily backups (free tier includes 7 days of backups)

---

## Support Resources

### Documentation

- **Supabase:** https://supabase.com/docs
- **Clerk:** https://clerk.com/docs
- **Cloudflare R2:** https://developers.cloudflare.com/r2
- **Vercel:** https://vercel.com/docs
- **Drizzle ORM:** https://orm.drizzle.team/docs

### Community Support

- **Supabase Discord:** https://discord.supabase.com
- **Clerk Discord:** https://clerk.com/discord
- **Vercel Community:** https://github.com/vercel/vercel/discussions

### Professional Support

If you need hands-on migration assistance:

- **Supabase Experts:** https://supabase.com/partners/experts
- **Clerk Partners:** https://clerk.com/partners
- **Freelance Platforms:** Upwork, Toptal (search for "React + tRPC + PostgreSQL migration")

---

## Conclusion

Migrating from Manus to free services will give you full control over your infrastructure while eliminating hosting costs. The migration requires moderate technical expertise but is well-documented and supported by active communities.

**Key Takeaways:**

1. **Database migration** is the most time-consuming step (2-3 hours) due to syntax differences
2. **Authentication migration** requires the most code changes but Clerk provides excellent documentation
3. **File storage migration** is straightforward thanks to S3-compatible APIs
4. **Hosting migration** to Vercel is the easiest step with zero-config deployment
5. **Total migration time:** 8-12 hours for a competent developer

**Next Steps:**

1. Review this guide thoroughly
2. Set up free accounts for all services (Supabase, Clerk, Cloudflare, Vercel)
3. Create a test environment to practice migration before touching production
4. Follow the phases in order, testing after each phase
5. Keep Manus environment running until migration is fully validated

Good luck with your migration! The Growth Farm platform will continue to serve your team well on its new infrastructure.

---

**Document End**
