ALTER TABLE `users` ADD `birthplace` varchar(255);--> statement-breakpoint
ALTER TABLE `users` ADD `lifePurpose` text;--> statement-breakpoint
ALTER TABLE `users` ADD `personalGoal` text;--> statement-breakpoint
ALTER TABLE `users` ADD `skillMastering` text;